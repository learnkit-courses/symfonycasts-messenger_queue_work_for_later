<?php

namespace App\Message\Query;

class GetTotalImageCount
{

}
